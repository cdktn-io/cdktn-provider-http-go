/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataHttpConfig extends cdktn.TerraformMetaArguments {
    /**
    * Certificate Authority (CA) in [PEM (RFC 1421)](https://datatracker.ietf.org/doc/html/rfc1421) format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/http/3.6.0/docs/data-sources/http#ca_cert_pem DataHttp#ca_cert_pem}
    */
    readonly caCertPem?: string;
    /**
    * Client certificate in [PEM (RFC 1421)](https://datatracker.ietf.org/doc/html/rfc1421) format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/http/3.6.0/docs/data-sources/http#client_cert_pem DataHttp#client_cert_pem}
    */
    readonly clientCertPem?: string;
    /**
    * Client key in [PEM (RFC 1421)](https://datatracker.ietf.org/doc/html/rfc1421) format.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/http/3.6.0/docs/data-sources/http#client_key_pem DataHttp#client_key_pem}
    */
    readonly clientKeyPem?: string;
    /**
    * Disables verification of the server's certificate chain and hostname. Defaults to `false`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/http/3.6.0/docs/data-sources/http#insecure DataHttp#insecure}
    */
    readonly insecure?: boolean | cdktn.IResolvable;
    /**
    * The HTTP Method for the request. Allowed methods are a subset of methods defined in [RFC7231](https://datatracker.ietf.org/doc/html/rfc7231#section-4.3) namely, `GET`, `HEAD`, and `POST`. `POST` support is only intended for read-only URLs, such as submitting a search.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/http/3.6.0/docs/data-sources/http#method DataHttp#method}
    */
    readonly method?: string;
    /**
    * The request body as a string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/http/3.6.0/docs/data-sources/http#request_body DataHttp#request_body}
    */
    readonly requestBody?: string;
    /**
    * A map of request header field names and values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/http/3.6.0/docs/data-sources/http#request_headers DataHttp#request_headers}
    */
    readonly requestHeaders?: {
        [key: string]: string;
    };
    /**
    * The request timeout in milliseconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/http/3.6.0/docs/data-sources/http#request_timeout_ms DataHttp#request_timeout_ms}
    */
    readonly requestTimeoutMs?: number;
    /**
    * The URL for the request. Supported schemes are `http` and `https`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/http/3.6.0/docs/data-sources/http#url DataHttp#url}
    */
    readonly url: string;
    /**
    * retry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/http/3.6.0/docs/data-sources/http#retry DataHttp#retry}
    */
    readonly retry?: DataHttpRetry;
}
export interface DataHttpRetry {
    /**
    * The number of times the request is to be retried. For example, if 2 is specified, the request will be tried a maximum of 3 times.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/http/3.6.0/docs/data-sources/http#attempts DataHttp#attempts}
    */
    readonly attempts?: number;
    /**
    * The maximum delay between retry requests in milliseconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/http/3.6.0/docs/data-sources/http#max_delay_ms DataHttp#max_delay_ms}
    */
    readonly maxDelayMs?: number;
    /**
    * The minimum delay between retry requests in milliseconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/http/3.6.0/docs/data-sources/http#min_delay_ms DataHttp#min_delay_ms}
    */
    readonly minDelayMs?: number;
}
export declare function dataHttpRetryToTerraform(struct?: DataHttpRetry | cdktn.IResolvable): any;
export declare function dataHttpRetryToHclTerraform(struct?: DataHttpRetry | cdktn.IResolvable): any;
export declare class DataHttpRetryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataHttpRetry | cdktn.IResolvable | undefined;
    set internalValue(value: DataHttpRetry | cdktn.IResolvable | undefined);
    private _attempts?;
    get attempts(): number;
    set attempts(value: number);
    resetAttempts(): void;
    get attemptsInput(): number | undefined;
    private _maxDelayMs?;
    get maxDelayMs(): number;
    set maxDelayMs(value: number);
    resetMaxDelayMs(): void;
    get maxDelayMsInput(): number | undefined;
    private _minDelayMs?;
    get minDelayMs(): number;
    set minDelayMs(value: number);
    resetMinDelayMs(): void;
    get minDelayMsInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/http/3.6.0/docs/data-sources/http http}
*/
export declare class DataHttp extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "http";
    /**
    * Generates CDKTN code for importing a DataHttp resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataHttp to import
    * @param importFromId The id of the existing DataHttp that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/http/3.6.0/docs/data-sources/http#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataHttp to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/http/3.6.0/docs/data-sources/http http} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataHttpConfig
    */
    constructor(scope: Construct, id: string, config: DataHttpConfig);
    get body(): string;
    private _caCertPem?;
    get caCertPem(): string;
    set caCertPem(value: string);
    resetCaCertPem(): void;
    get caCertPemInput(): string | undefined;
    private _clientCertPem?;
    get clientCertPem(): string;
    set clientCertPem(value: string);
    resetClientCertPem(): void;
    get clientCertPemInput(): string | undefined;
    private _clientKeyPem?;
    get clientKeyPem(): string;
    set clientKeyPem(value: string);
    resetClientKeyPem(): void;
    get clientKeyPemInput(): string | undefined;
    get id(): string;
    private _insecure?;
    get insecure(): boolean | cdktn.IResolvable;
    set insecure(value: boolean | cdktn.IResolvable);
    resetInsecure(): void;
    get insecureInput(): boolean | cdktn.IResolvable | undefined;
    private _method?;
    get method(): string;
    set method(value: string);
    resetMethod(): void;
    get methodInput(): string | undefined;
    private _requestBody?;
    get requestBody(): string;
    set requestBody(value: string);
    resetRequestBody(): void;
    get requestBodyInput(): string | undefined;
    private _requestHeaders?;
    get requestHeaders(): {
        [key: string]: string;
    };
    set requestHeaders(value: {
        [key: string]: string;
    });
    resetRequestHeaders(): void;
    get requestHeadersInput(): {
        [key: string]: string;
    } | undefined;
    private _requestTimeoutMs?;
    get requestTimeoutMs(): number;
    set requestTimeoutMs(value: number);
    resetRequestTimeoutMs(): void;
    get requestTimeoutMsInput(): number | undefined;
    get responseBody(): string;
    get responseBodyBase64(): string;
    private _responseHeaders;
    get responseHeaders(): cdktn.StringMap;
    get statusCode(): number;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
    private _retry;
    get retry(): DataHttpRetryOutputReference;
    putRetry(value: DataHttpRetry): void;
    resetRetry(): void;
    get retryInput(): cdktn.IResolvable | DataHttpRetry | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
